<?php
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "invest"; 

$conn = new mysqli($servername, $username, $password, $database);

?>
